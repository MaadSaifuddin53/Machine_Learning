
import pickle
def predict(text):
	vectorizer = pickle.load(open("vector.pickel", "rb"))
	encoder = pickle.load(open("encoder.pickel", "rb"))
	model=pickle.load(open("LinearSVCModel.pickel", "rb"))
	print("Predicting tweet: {}".format(text))
	custom_pred = model.predict(vectorizer.transform([text]))
	print("Result: {}".format(encoder.inverse_transform(custom_pred)))
			
	
