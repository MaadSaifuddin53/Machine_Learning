

Instruction for running program

1 First you need to all your file in one folder (vector file,encoder file,model file,model.py)
2 Second import the modle.py file as
import model
It contain predict function
Simply u need to call 
model.predict function and input text in in it will print the text and its category as a output.

Sample code

import model
text="Amir took 5 wicket in todays match"
model.predict(text) 
